{{- define "n8n-pcai.labels" -}}
app.kubernetes.io/name: n8n
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
hpe-ezua/app: {{ .Release.Name | quote }}
hpe-ezua/type: vendor-service
{{- end -}}
{{- define "n8n-pcai.dbname" -}}
{{ .Release.Name }}-database
{{- end -}}
{{- define "n8n-pcai.webname" -}}
{{ .Release.Name }}-app
{{- end -}}
